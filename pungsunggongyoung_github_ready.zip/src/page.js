export default function Home() {
  return (
    <main style={{ textAlign: "center", padding: "50px" }}>
      <h1>(주) 풍성공영</h1>
      <p>우레탄 뿜칠 및 건축 시공 전문 기업</p>
      <p>시공 의뢰 및 상담을 원하시면 아래 버튼을 클릭하세요.</p>
      <button style={{ marginTop: "20px", padding: "10px 20px" }}>시공 의뢰하기</button>
    </main>
  );
}
